"""Usage: python train.py /path/to/f1_driver_race_laps.csv (outputs beside script)."""
import sys
from pathlib import Path
from copy import deepcopy
import pandas as pd
import torch
from pit_mlp import FEATURES, PitMLP

OUT = Path(__file__).resolve().parent
SEED = 682
torch.set_num_threads(1)
torch.use_deterministic_algorithms(True)
columns = ['year', 'round', 'driver_id', 'lap', 'mlp_ready', 'pit', *FEATURES]
df = pd.read_csv(sys.argv[1], usecols=columns)
df = df[df.mlp_ready.eq(1)].copy()
silverstone = df.year.eq(2019) & df['round'].eq(10)
ver = df.driver_id.eq('max_verstappen')
cohorts = {
    '1_VER_Silverstone': silverstone & ver,
    '2_All_Silverstone': silverstone,
    '3_All_since_2019': df.year.ge(2019),
    '4_VER_career': ver,
    '5_HAM_career': df.driver_id.eq('hamilton'),
    '6_LEC_career': df.driver_id.eq('leclerc'),
}
results, histories, manifests = [], [], []
for i, (name, mask) in enumerate(cohorts.items()):
    data = df.loc[mask].copy()
    group = ['lap'] if i < 2 else ['year','round']
    units = data[group].drop_duplicates().sort_values(group).reset_index(drop=True)
    n = len(units)
    a, b = n * 70 // 100, n * 85 // 100
    units['split'] = ['train']*a + ['val']*(b-a) + ['test']*(n-b)
    data = data.merge(units, on=group, validate='m:1')
    counts = data.groupby(['year','round', *(['lap'] if i < 2 else []), 'split']).pit.agg(rows='size', pits='sum')
    manifests.append(counts.reset_index().assign(cohort=name))
    parts = {k: data[data.split.eq(k)] for k in ('train','val','test')}
    def arrays(part):
        return tuple(torch.as_tensor(a.to_numpy(), dtype=torch.float32) for a in (part[list(FEATURES)], part.pit))
    x, y = arrays(parts['train'])
    xv, yv = arrays(parts['val'])
    torch.manual_seed(SEED)
    model = PitMLP()
    optimizer = torch.optim.Adam(model.parameters(), lr=.01)
    best_loss, best_epoch = float('inf'), 0
    for epoch in range(1, 101):
        model.train()
        for idx in torch.randperm(len(x)).split(512):
            optimizer.zero_grad()
            model.loss(x[idx], y[idx]).backward()
            optimizer.step()
        model.eval()
        with torch.no_grad():
            val_loss = model.loss(xv, yv).item()
        histories.append(dict(cohort=name, epoch=epoch, val_bce=val_loss))
        if val_loss < best_loss:
            best_state = deepcopy(model.state_dict())
            best_loss, best_epoch = val_loss, epoch
        if epoch - best_epoch >= 12:
            break
    model.load_state_dict(best_state)
    if len(yv.unique()) == 2:
        model.select_threshold(xv, yv)
        threshold_rule = 'max_validation_F1'
    else:
        model.threshold = .5
        threshold_rule = 'fixed_0.5_single_class_validation'
    path = OUT / (name + '.pt')
    model.save_checkpoint(path)
    restored = PitMLP.load_checkpoint(path)
    assert torch.equal(restored(xv), model(xv)) and restored.threshold == model.threshold
    for split, part in parts.items():
        xx, yy = arrays(part)
        metrics = restored.evaluate(xx, yy)
        pred = restored.predict(xx)
        pos = yy.bool()
        tp, fp = (pred & pos).sum().item(), (pred & ~pos).sum().item()
        fn, tn = (~pred & pos).sum().item(), (~pred & ~pos).sum().item()
        assert tp + fp + fn + tn == len(part)
        if not pos.any():
            for metric in ('ap','recall','f1'):
                metrics[metric] = None
        if not pred.any():
            metrics['precision'] = None
        results.append(dict(cohort=name, split=split, first_year=part.year.min(), last_year=part.year.max(),
                            races=len(part[['year','round']].drop_duplicates()), drivers=part.driver_id.nunique(),
                            rows=len(part), pits=int(pos.sum()), pit_rate=pos.double().mean().item(),
                            epochs_run=epoch, selected_epoch=best_epoch, threshold=model.threshold,
                            threshold_rule=threshold_rule, tp=tp, fp=fp, fn=fn, tn=tn, **metrics))
    print(name, len(data), best_epoch, model.threshold, flush=True)
pd.DataFrame(results).to_csv(OUT/'metrics.csv',index=False)
pd.concat(manifests, ignore_index=True).to_csv(OUT/'split_manifest.csv',index=False)
pd.DataFrame(histories).to_csv(OUT/'validation_history.csv',index=False)
