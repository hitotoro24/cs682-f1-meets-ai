"""Run a saved pit classifier in the team's Silverstone VSE policy callback."""
import argparse
from pathlib import Path

import pandas as pd
import torch

from .pit_mlp import FEATURES, PitMLP
from .pit_pipeline import encode
from .sim_policy import historical_policy, other_strategies_unchanged, run_policy


class LearnedPitPolicy:
    def __init__(self, checkpoint):
        self.model = PitMLP.load_checkpoint(checkpoint)
        self.decisions = []

    @torch.inference_mode()
    def __call__(self, state):
        # Training omits lap 1 because no completed previous lap exists.
        if state.lap == 1:
            return None
        x = encode(state.lap, state.total_laps, state.position_prev_lap,
                   state.stops_so_far, state.field_size)
        probability = self.model.predict_proba(torch.from_numpy(x).unsqueeze(0)).item()
        requested = probability >= self.model.threshold
        self.decisions.append({
            'lap': state.lap, **dict(zip(FEATURES, x)), 'pit_probability': probability,
            'threshold': self.model.threshold, 'requested_pit': requested,
        })
        if not requested or state.lap == state.total_laps:
            return None
        # The binary model chooses timing. Use the first different dry compound
        # in the simulator's configured order for this Silverstone dry race.
        return next(c for c in state.available_compounds if c != state.compound)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--checkpoint', type=Path, required=True)
    parser.add_argument('--out', type=Path, default=Path('local_results/mlp_policy'))
    args = parser.parse_args()
    policy = LearnedPitPolicy(args.checkpoint)
    baseline = run_policy(historical_policy)
    learned = run_policy(policy)
    if not all(r.outcome['actions_executed'] and r.outcome['finished'] for r in (baseline, learned)):
        raise RuntimeError('Incomplete race or a requested action was not executed.')
    if not other_strategies_unchanged(baseline, learned):
        raise RuntimeError('A non-target driver changed strategy.')
    trace = learned.trace.merge(pd.DataFrame(policy.decisions), on='lap', how='left', validate='1:1')
    trace['executed_pit'] = trace.lap.isin(learned.outcome['stops'])
    args.out.mkdir(parents=True, exist_ok=True)
    trace.to_csv(args.out / 'decisions.csv', index=False)
    outcomes = pd.DataFrame([{'policy': name, **r.outcome}
                             for name, r in [('historical', baseline), ('mlp', learned)]])
    outcomes.to_csv(args.out / 'outcomes.csv', index=False)
    print(outcomes[['policy', 'stops', 'laps', 'position', 'seconds', 'used_two_compounds']].to_string(index=False))


if __name__ == '__main__':
    main()
